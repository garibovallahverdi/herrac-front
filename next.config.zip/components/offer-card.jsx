import React from 'react'

const OfferCard = ({fullname, date, hours, price}) => {
  return (
    <div className='flex items-center justify-between '>
        <span>{fullname}</span>
        <div className='flex items-center gap-[10px]'>
            <span>{date}</span>
            <span>{hours}</span>
        </div>
        <span>{price}₼</span>
    </div>
  )
}

export default OfferCard
