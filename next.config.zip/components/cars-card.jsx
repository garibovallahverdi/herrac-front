import React from 'react'

const CarsCard = ({ title1, title2, title3, text1, text2, text3, bg }) => {
  return (
    <div>
      <div className={`grid grid-cols-3 px-[24px] py-[16px] ${bg ? "bg-[#F2F2F4] bg-opacity-75" : ""} `}>
        <div className="flex items-center gap-[5px]">
          <span className="text-[16px] font-semibold text-[#04011B]">{title1}</span>
          <span className="text-[16px]">{text1}</span>
        </div>
        <div className="flex items-center justify-start gap-[5px] ">
          <span className="text-[16px] font-semibold text-[#04011B]">{title2}</span>
          <span className="text-[16px]">{text2}</span>
        </div>
        <div className="flex items-center justify-start gap-[5px]">
          <span className="text-[16px] font-semibold text-[#04011B]">{title3}</span>
          <span className="text-[16px]">{text3}</span>
        </div>
      </div>
    </div>
  )
}

export default CarsCard
