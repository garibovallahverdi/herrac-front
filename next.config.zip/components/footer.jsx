import React from 'react'
import logoPoint from '../public/svgs/Logo-point.svg'
import sosiaIcons from '../public/svgs/sosial-icons.svg'
import footerImg1 from '../public/imgs/footer-img1.png'
import footerImg2 from '../public/imgs/footer-img2.png'
import footerImg3 from '../public/imgs/footer-img3.png'
import footerImg4 from '../public/imgs/footer-img4.png'
import footerImg5 from '../public/imgs/footer-img5.png'
import footerImg6 from '../public/imgs/footer-img6.png'
import Image from 'next/image'
import Link from 'next/link'

const Footer = () => {
    return (
        <div className='w-full max-w-[1550px] mx-auto lg:px-[80px] md:px-[40px] px-[16px] md:pt-[80px] pt-[30px] bg-[#050123]'>
            <div className='pb-[60px] grid md:grid-cols-4 gap-y-[50px]'>
                <div className='flex flex-col'>
                    <div className='flex items-start'>
                        <span className='text-[#E70000] text-[30px] font-extrabold'>AUTO</span>
                        <span className='text-[#fff] text-[30px] font-extrabold'>ME.AZ</span>
                        <Image src={logoPoint} alt='Logo point' className='mt-[11px] ms-[2px]' />
                    </div>
                    <span className='text-[#fff] text-opacity-75 text-[14px]'>Hər kolleksiya bir hekayə danışır. Biz sizə bu hekayəni yaşatmaq fürsətini təklif edirik.</span>
                    <div className='mt-[25px]'>
                        <span className='text-[#fff] font-medium'>Bizi izləyin</span>
                        <div className='flex items-center gap-[20px] mt-[10px]'>
                            <div className='w-[36px] h-[36px] bg-[#fff] hover:bg-[#e70000] flex items-center justify-center rounded-[36px] duration-300'>
                                <Link href='https://www.instagram.com/' target='_blank'>
                                    <svg className='hover:fill-[#fff] fill-[#e70000] duration-300' xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill='none'>
                                        <path d="M9.92538 0.00110732C10.5821 -0.0014128 11.2389 0.00518768 11.8954 0.0209067L12.07 0.0272065C12.2716 0.0344062 12.4705 0.0434059 12.7108 0.0542055C13.6684 0.099204 14.3217 0.250399 14.895 0.472691C15.489 0.701284 15.9894 1.01087 16.4898 1.51126C16.9473 1.96089 17.3014 2.50477 17.5274 3.1051C17.7497 3.67838 17.9009 4.33266 17.9459 5.29023C17.9567 5.52962 17.9657 5.72941 17.9729 5.93101L17.9783 6.1056C17.9943 6.76185 18.0012 7.41829 17.999 8.07473L17.9999 8.74611V9.92507C18.0021 10.5818 17.9952 11.2386 17.9792 11.8951L17.9738 12.0697C17.9666 12.2713 17.9576 12.4702 17.9468 12.7105C17.9018 13.668 17.7488 14.3214 17.5274 14.8947C17.3021 15.4957 16.9479 16.04 16.4898 16.4894C16.0397 16.9469 15.4956 17.301 14.895 17.5271C14.3217 17.7494 13.6684 17.9006 12.7108 17.9456C12.4705 17.9564 12.2716 17.9654 12.07 17.9726L11.8954 17.978C11.2389 17.994 10.5821 18.0009 9.92538 17.9987L9.254 17.9996H8.07594C7.4192 18.0018 6.76246 17.9949 6.10591 17.9789L5.93132 17.9735C5.71767 17.9658 5.50408 17.9568 5.29054 17.9465C4.33297 17.9015 3.67959 17.7485 3.10541 17.5271C2.50485 17.3015 1.96087 16.9474 1.51157 16.4894C1.05352 16.0397 0.699097 15.4955 0.473003 14.8947C0.250711 14.3214 0.0995159 13.668 0.0545174 12.7105C0.0444944 12.4969 0.0354946 12.2833 0.0275183 12.0697L0.0230186 11.8951C0.00642639 11.2386 -0.00107416 10.5818 0.000519283 9.92507V8.07473C-0.0019925 7.41829 0.00460798 6.76185 0.0203187 6.1056L0.0266184 5.93101C0.0338182 5.72941 0.0428179 5.52962 0.0536175 5.29023C0.098616 4.33176 0.249811 3.67928 0.472103 3.1051C0.698331 2.50448 1.05345 1.96074 1.51247 1.51216C1.96146 1.05385 2.5051 0.699099 3.10541 0.472691C3.67959 0.250399 4.33207 0.099204 5.29054 0.0542055L5.93132 0.0272065L6.10591 0.0227067C6.76215 0.00612283 7.41859 -0.00137772 8.07504 0.000207414L9.92538 0.00110732ZM9.00021 4.50095C8.40399 4.49252 7.81203 4.60267 7.25875 4.825C6.70547 5.04734 6.20189 5.37742 5.77728 5.79606C5.35268 6.2147 5.01551 6.71356 4.78538 7.26365C4.55524 7.81373 4.43673 8.40407 4.43673 9.00035C4.43673 9.59663 4.55524 10.187 4.78538 10.7371C5.01551 11.2871 5.35268 11.786 5.77728 12.2046C6.20189 12.6233 6.70547 12.9534 7.25875 13.1757C7.81203 13.398 8.40399 13.5082 9.00021 13.4997C10.1936 13.4997 11.3382 13.0257 12.1821 12.1818C13.026 11.3379 13.5001 10.1933 13.5001 8.9999C13.5001 7.80647 13.026 6.66191 12.1821 5.81803C11.3382 4.97414 10.1936 4.50095 9.00021 4.50095ZM9.00021 6.30089C9.35886 6.29428 9.71522 6.35921 10.0485 6.49187C10.3818 6.62454 10.6853 6.82228 10.9412 7.07356C11.1972 7.32483 11.4006 7.6246 11.5394 7.95534C11.6783 8.28609 11.7498 8.64119 11.7499 8.99989C11.7499 9.3586 11.6785 9.71372 11.5398 10.0445C11.401 10.3753 11.1978 10.6751 10.9419 10.9265C10.686 11.1779 10.3826 11.3757 10.0493 11.5085C9.7161 11.6413 9.35976 11.7063 9.00111 11.6998C8.28505 11.6998 7.59832 11.4154 7.09199 10.909C6.58566 10.4027 6.30121 9.71596 6.30121 8.9999C6.30121 8.28384 6.58566 7.59711 7.09199 7.09078C7.59832 6.58445 8.28505 6.29999 9.00111 6.29999L9.00021 6.30089ZM13.7251 3.151C13.4347 3.16262 13.1601 3.28613 12.9588 3.49566C12.7575 3.70519 12.6451 3.98449 12.6451 4.27506C12.6451 4.56563 12.7575 4.84493 12.9588 5.05446C13.1601 5.26399 13.4347 5.3875 13.7251 5.39912C14.0234 5.39912 14.3096 5.2806 14.5205 5.06963C14.7315 4.85866 14.85 4.57252 14.85 4.27416C14.85 3.9758 14.7315 3.68967 14.5205 3.47869C14.3096 3.26772 14.0234 3.1492 13.7251 3.1492V3.151Z" />
                                    </svg>
                                </Link>
                            </div>
                            <div  className='w-[36px] h-[36px] bg-[#fff] hover:bg-[#e70000] flex items-center justify-center rounded-[36px] duration-300'>
                                <Link href='https://www.facebook.com/' target='_blank'>
                                    <svg className='hover:fill-[#fff] fill-[#e70000] duration-300' xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
                                        <path d="M18 9.05512C18 4.05399 13.9708 0 9.00113 0C4.02925 0.00112486 0 4.05399 0 9.05624C0 13.5748 3.29134 17.3206 7.5928 18V11.6727H5.30934V9.05624H7.59505V7.05962C7.59505 4.79078 8.93926 3.53768 10.9944 3.53768C11.9798 3.53768 13.009 3.71429 13.009 3.71429V5.94151H11.874C10.757 5.94151 10.4083 6.64005 10.4083 7.35658V9.05512H12.9033L12.5051 11.6715H10.4072V17.9989C14.7087 17.3195 18 13.5737 18 9.05512Z" />
                                    </svg>
                                </Link>
                            </div>
                            <div  className='w-[36px] h-[36px] bg-[#fff] hover:bg-[#e70000] flex items-center justify-center rounded-[36px] duration-300'>
                                <Link href='https://www.telegram.com/' target='_blank'>
                                    <svg  className='hover:fill-[#fff] fill-[#e70000] duration-300' xmlns="http://www.w3.org/2000/svg" width="21" height="17" viewBox="0 0 21 17" fill="none">
                                        <path d="M19.9755 1.52905L16.9524 15.7859C16.7242 16.7919 16.1296 17.0424 15.2845 16.5687L10.678 13.1742L8.45554 15.3122C8.2094 15.5584 8.00405 15.7637 7.52965 15.7637L7.86094 11.0727L16.3979 3.35865C16.7692 3.02808 16.317 2.84419 15.8212 3.17548L5.26716 9.82129L0.723567 8.39882C-0.264575 8.09043 -0.282463 7.41068 0.929639 6.93628L18.7012 0.0894136C19.524 -0.218978 20.2438 0.271873 19.9755 1.52905Z"  />
                                    </svg>
                                </Link>
                            </div>
                            <div  className='w-[36px] h-[36px] bg-[#fff] hover:bg-[#e70000] flex items-center justify-center rounded-[36px] duration-300'>
                                <Link href='https://www.youtube.com/' target='_blank'>
                                    <svg  className='hover:fill-[#fff] fill-[#e70000] duration-300' xmlns="http://www.w3.org/2000/svg" width="24" height="17" viewBox="0 0 24 17" fill="none">
                                        <path d="M9.6 12L15.828 8.4L9.6 4.8V12ZM23.472 2.604C23.628 3.168 23.736 3.924 23.808 4.884C23.892 5.844 23.928 6.672 23.928 7.392L24 8.4C24 11.028 23.808 12.96 23.472 14.196C23.172 15.276 22.476 15.972 21.396 16.272C20.832 16.428 19.8 16.536 18.216 16.608C16.656 16.692 15.228 16.728 13.908 16.728L12 16.8C6.972 16.8 3.84 16.608 2.604 16.272C1.524 15.972 0.828 15.276 0.528 14.196C0.372 13.632 0.264 12.876 0.192 11.916C0.108 10.956 0.0719999 10.128 0.0719999 9.408L0 8.4C0 5.772 0.192 3.84 0.528 2.604C0.828 1.524 1.524 0.828 2.604 0.528C3.168 0.372 4.2 0.264 5.784 0.192C7.344 0.108 8.772 0.0719999 10.092 0.0719999L12 0C17.028 0 20.16 0.192 21.396 0.528C22.476 0.828 23.172 1.524 23.472 2.604Z" />
                                    </svg>
                                </Link>
                            </div>
                        </div>
                    </div>
                </div>
                <div className='flex md:justify-center'>
                    <div>
                        <span className='text-[#fff] font-medium text-[16px]'>Vacib linklər</span>
                        <ul className='grid grid-cols-1 gap-[10px] mt-[20px] text-[#fff] text-opacity-75 text-[14px]'>
                            <li><Link href="/">Hərrac</Link></li>
                            <li><Link href="/">Kateqoriya</Link></li>
                            <li><Link href="/">Məkan</Link></li>
                            <li><Link href="/">Xidmət</Link></li>
                            <li><Link href="/">Qaydalar</Link></li>
                        </ul>
                    </div>
                </div>
                <div className='flex md:justify-center'>
                    <div>
                        <span className='text-[#fff] font-medium text-[16px]'>Kömək və dəstək</span>
                        <ul className='grid grid-cols-1 gap-[10px] mt-[20px] text-[#fff] text-opacity-75 text-[14px]'>
                            <li><Link href='/'>Haqqımızda</Link></li>
                            <li><Link href='/'>FAQ</Link></li>
                            <li><Link href='/'>Qiymətlər</Link></li>
                            <li><Link href='/'>Dəstək</Link></li>
                            <li><Link href='/'>Yardım mərkəzi</Link></li>
                        </ul>
                    </div>
                </div>
                <div className='flex md:justify-end'>
                    <div>
                        <div>
                            <span className='text-[#fff] font-medium text-[16px]'>Əlaqə</span>
                            <ul className='grid grid-cols-1 gap-[10px] mt-[20px] text-[#fff] text-opacity-75 text-[14px]'>
                                <li><Link href='/'>Verdiyiniz feedbacklər bizim üçün önəmlidir.</Link></li>
                                <li><Link href='/'>Phone: +994 99 315 54 75</Link></li>
                                <li><Link href='/'>E-mail: infoherrac.org@gmail.com</Link></li>
                            </ul>
                        </div>
                        <div className='mt-[10px]'>
                            <span className='text-[#fff] font-medium text-[16px]'>İnstagramdan</span>
                            <ul className='grid grid-cols-3 '>
                                <li><Image src={footerImg1} alt='Footer img-1' /></li>
                                <li><Image src={footerImg2} alt='Footer img-2' /></li>
                                <li><Image src={footerImg3} alt='Footer img-3' /></li>
                                <li><Image src={footerImg4} alt='Footer img-4' /></li>
                                <li><Image src={footerImg5} alt='Footer img-5' /></li>
                                <li><Image src={footerImg6} alt='Footer img-6' /></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div className='border-t-[1px] border-[#fff] border-opacity-75 py-[10px] flex justify-center'>
                <span className='text-[#fff] text-opacity-75 text-[12px] font-medium'>© HƏRRAC.ORG - Bütün Hüquqlar Qorunur</span>
            </div>
        </div>
    )
}

export default Footer
