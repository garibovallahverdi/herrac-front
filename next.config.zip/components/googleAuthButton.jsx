'use client'
import React from 'react'
import google from '../public/svgs/Google.svg'
import Image from 'next/image';

const GoogleAuthButton = () => {
    const handleLogin = () => {
        window.location.href = 'http://localhost:9000/auth/google';
      // window.open('http://localhost:9000/auth/google', '_blank');      
    };

  return (
               <button onClick={handleLogin} className='flex items-center justify-center gap-[8px] bg-[#E6E6E9] rounded-[8px] py-[10px] text-[#04011B] font-semibold mt-6 md:mt-0'>
                    <Image src={google} alt='google'/>
                    Google 
                </button>
  )
}

export default GoogleAuthButton