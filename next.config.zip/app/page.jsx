'use client'
import Link from "next/link";
import AntiquesImg from '../public/imgs/Antiques-img.png'
import CarsImg from '../public/imgs/Cars-img.png'
import ElectronicsImg from '../public/imgs/Electronics-img.png'
import AccessioriesImg from '../public/imgs/Accessiories-img.png'
import infoImg from '../public/imgs/info-img.png'
import nowBuy from '../public/imgs/now-buy.png'
import indicatorIcon1 from '../public/svgs/indicatorIcon1.svg'
import indicatorIcon2 from '../public/svgs/indicatorIcon2.svg'
import indicatorIcon3 from '../public/svgs/indicatorIcon3.svg'
import indicatorIcon4 from '../public/svgs/indicatorIcon4.svg'
import homeTitle from '../public/svgs/home-title.svg'
import sticker1 from '../public/imgs/sticker-img1.png'
import sticker2 from '../public/imgs/sticker-img2.png'
import sticker3 from '../public/imgs/sticker-img3.png'
import sticker4 from '../public/imgs/sticker-img4.png'
import carImg1 from '../public/imgs/now-start-img.png'
import carImg2 from '../public/imgs/now-start-img-2.png'
import Motosiklet from '../public/imgs/Motosiklet.png'
import Rodster from '../public/imgs/Rodster.png'
import Universal from '../public/imgs/Universal.png'
import Sedan from '../public/imgs/Sedan.png'
import Pikap from '../public/imgs/Pikap.jpeg'
import YukMashını from '../public/imgs/Yük maşını.jpeg'
import Kupe from '../public/imgs/Kupe.jpeg'
import homeImg from '../public/imgs/home-img.png'
import Image from "next/image";
import Card from "@/components/card";
import AboutCard from "@/components/aboutCard";
import IndicatorCard from "@/components/indicatorCard";
import { useEffect, useState } from "react";
import { fetchProduct } from "./utils/productUtil";


export default function Home() {
  // const prductData = [1, 2, 3, 4]
  const aboutData = [1, 2, 3]

  const [data, setData] = useState([]);

  useEffect(() => {
    async function getData() {
      const content = await fetchProduct();
      setData(content);
    }
    getData();
  }, []);
  return (
    <div className="w-full max-w-[1550px] mx-auto ">
      <div className="w-full flex gap-[20px] md:flex-row flex-col justify-between xl:ps-[80px] lg:ps-[40px] md:ps-[20px] ps-[16px] bg-[#FFFDEF]">
        <div className="flex flex-col md:items-start items-center md:w-1/2 w-full md:py-[96px] py-[30px]">
          <span className="text-[#E70000] font-medium md:text-[16px] text-[12px] ">HƏRRACIN FAVORİ MƏTKƏZİ</span>
          <span className="lg:text-[36px] md:text-[28px] text-[24px] font-medium text-[#050123] lg:me-[95px] md:text-start text-center">Bənzərsiz məhsulların axtarırsınız? İndi qoşulun və ən yaxşı təklifləri əldə edin!</span>
          <span className="text-[#44415A] mt-[16px] md:text-[18px] text-[16px] md:text-start text-center">Dəyərli istifadəçilərimizə xüsusi təcrübə təqdim etmək üçün buradayıq! Onlayn auksionlarla dolu maraqlı dünyaya addım atın və istədiyiniz əşyaları ən yaxşı qiymətlərlə əldə edin.</span>
          <Link href='/products' className="px-[40px] py-[15px] font-bold md:text-[24px] text-[16px] text-[#fff] rounded-[8px] bg-[#E70000] md:mt-[50px] mt-[30px]">Elə indi başla</Link>
        </div>
        <div className="flex items-start justify-center md:w-1/2 w-full">
          <Image src={carImg1} alt="home img" className="w-full h-full md:block hidden" />
          <Image src={carImg2} alt="home img" className="w-full h-full md:hidden block" />
        </div>
      </div>
      <div id="scroll" className="md:px-[80px] px-[16px] md:max-w-[2250px] max-w-[1300px] mx-auto overflow-auto md:my-[160px] my-[80px] ">
        <div className="grid grid-cols-7 md:justify-center md:gap-[32px] gap-[15px] md:w-[2250px] w-[1300px] md:h-[186px] h-[105px]">
          <div className="relative rounded-[24px] overflow-hidden ">
            <Image src={Motosiklet} alt="Motosiklet" className="w-full h-full" />
            <div className="absolute left-0 top-0 w-full h-full bg-[#000] bg-opacity-25 flex items-center justify-center">
              <span className="bg-[#000] bg-opacity-50 md:px-[44px] px-[18px] md:py-[12px] py-[10px] md:text-[24px] text-[16px] mx-[20px] font-bold text-[#fff] rounded-[8px]">Motosiklet</span>
            </div>
          </div>
          <div className="relative rounded-[24px] overflow-hidden ">
            <Image src={Rodster} alt="Rodster" className="w-full h-full" />
            <div className="absolute left-0 top-0 w-full h-full bg-[#000] bg-opacity-25 flex items-center justify-center">
              <span className="bg-[#000] bg-opacity-50 md:px-[44px] px-[18px] md:py-[12px] py-[10px] md:text-[24px] text-[16px] font-bold text-[#fff] rounded-[8px]">Rodster</span>
            </div>
          </div>
          <div className="relative rounded-[24px] overflow-hidden ">
            <Image src={Universal} alt="Universal" className="w-full h-full" />
            <div className="absolute left-0 top-0 w-full h-full bg-[#000] bg-opacity-25 flex items-center justify-center">
              <span className="bg-[#000] bg-opacity-50 rounded-[8px] md:px-[44px] px-[18px] md:py-[12px] py-[10px] md:text-[24px] text-[16px] font-bold text-[#fff]">Universal</span>
            </div>
          </div>
          <div className="relative rounded-[24px] overflow-hidden ">
            <Image src={Sedan} alt="Sedan" className="w-full h-full" />
            <div className="absolute left-0 top-0 w-full h-full bg-[#000] bg-opacity-25 flex items-center justify-center">
              <span className="md:px-[44px] px-[18px] md:py-[12px] py-[10px] md:text-[24px] text-[16px] text-[#fff] bg-[#000] bg-opacity-50 font-bold rounded-[8px]">Sedan</span>
            </div>
          </div>
          <div className="relative rounded-[24px] overflow-hidden ">
            <Image src={Pikap} alt="Pikap" className="w-full h-full" />
            <div className="absolute left-0 top-0 w-full h-full bg-[#000] bg-opacity-25 flex items-center justify-center">
              <span className="md:px-[44px] px-[18px] md:py-[12px] py-[10px] md:text-[24px] text-[16px] text-[#fff] bg-[#000] bg-opacity-50 font-bold rounded-[8px]">Pikap</span>
            </div>
          </div>
          <div className="relative rounded-[24px] overflow-hidden ">
            <Image src={YukMashını} alt="Yük maşını" className="w-full h-full" />
            <div className="absolute left-0 top-0 w-full h-full bg-[#000] bg-opacity-25 flex items-center justify-center">
              <span className="md:px-[44px] px-[18px] md:py-[12px] py-[10px] md:text-[24px] text-[16px] text-[#fff] bg-[#000] bg-opacity-50 font-bold rounded-[8px]">Yük maşını</span>
            </div>
          </div>
          <div className="relative rounded-[24px] overflow-hidden ">
            <Image src={Kupe} alt="Kupe" className="w-full h-full" />
            <div className="absolute left-0 top-0 w-full h-full bg-[#000] bg-opacity-25 flex items-center justify-center">
              <span className="md:px-[44px] px-[18px] md:py-[12px] py-[10px] md:text-[24px] text-[16px] text-[#fff] bg-[#000] bg-opacity-50 font-bold rounded-[8px] font-times">Kupe</span>
            </div>
          </div>
        </div>
      </div>
      <div className="relative bg-gradient-to-t from-[#fff] via-[#FFCACA] to-[#FFCACA]">
        <div className="flex flex-col items-center justify-center py-[72px] ">
          <span className="md:text-[16px] text-[14px] text-[#E70000]">Vaxt itirmədən indi başla</span>
          <span className="md:text-[50px] text-[22px] font-medium text-[#050123] xl:w-[50%] lg:w-[60%] md:w-[70%] text-center">HƏRRAC.ORG Hərrac: Unikal Fürsətləri Qaçırmayın!</span>
          <p className="py-[24px] text-[16px] text-[#44415a] md:-[40%] text-center">Hərrac keçirməklə özəl məhsulları sərfəli qiymətlərlə satmaq şansınız var, mövcud fürsətlərdən dəyərləndirin.</p>
          <ul className="flex flex-wrap items-center justify-center gap-x-[50px] gap-y-[25px] text-[16px] list-disc text-[#050123]">
            <li>Hərracın adı</li>
            <li>Hərracın detayları</li>
            <li>Hərracın qiyməti</li>
            <li>Hərracın vaxtı</li>
            <li>Hərracın məkanı</li>
          </ul>
          <div className="flex items-center md:gap-x-[36px] gap-x-[19px]">
            <Link href='/announcement' className="mt-[40px] md:px-[32px] px-[26px] md:py-[16px] py-[10px] rounded-[8px] bg-[#E70000] text-[#fff] text-[16px] font-medium">Hərrac elan et</Link>
            <Link href='/announcement' className="mt-[40px] md:px-[32px] px-[26px] md:py-[16px] py-[10px] rounded-[8px] bg-[#04011B] text-[#fff] text-[16px] font-medium">Elan yerləşdir</Link>
          </div>
        </div>
        <div className="">
          <Image src={sticker1} alt="sticker-1" className="md:block hidden w-[100px] h-[100px] rounded-[100px] absolute lg:left-[172px] md:left-[30px] top-[151px]" />
          <Image src={sticker2} alt="sticker-2" className="md:block hidden w-[50px] h-[50px] rounded-[100px] absolute lg:left-[222px] md:left-[150px] top-[427px]" />
          <Image src={sticker3} alt="sticker-3" className="md:block hidden w-[60px] h-[60px] rounded-[200px] absolute lg:right-[316px] md:right-[200px] top-[36px]" />
          <Image src={sticker4} alt="sticker-4" className="md:block hidden w-[120px] h-[120px] rounded-[100px] absolute lg:right-[100px] md:right-[45px] top-[220px]" />
          <div className="md:block hidden w-[20px] h-[20px] bg-[#F410F9] rounded-[200px] absolute left-[120px] top-[350px]"></div>
          <div className="md:block hidden w-[20px] h-[20px] bg-[#FF6B00] rounded-[200px] absolute right-[291px] top-[477px]"></div>
        </div>
      </div>
      <div className="md:px-[80px] px-[16px] py-[80px]">
        <div className="flex flex-col items-center">
          <span className="md:text-[36px] text-[24px] font-semibold text-[#050123]">Hərracları kəşf et</span>
          <p className="mt-[10px] md:text-[18px] text-[16px] font-medium text-[#828091] mx-auto md:w-[70%] text-center">Növbəti hərracı hara etməyi istədiynizə qərar verin!</p>
        </div>
        <div className="mt-[60px] flex flex-col md:gap-y-[90px] gap-y-[80px]">
          <div>
            <div className="flex justify-between items-center">
              <span className="md:text-[24px] text-[18px] font-medium text-[#050123]">Trend</span>
              <Link href='/' className="md:text-[18px] text-[16px] font-medium text-[#E70000]">Hamsı</Link>
            </div>
            <div className="overflow-auto">
              <div className="mt-[16px] flex justify-between gap-[32px] min-w-[1220px]">
                {
                  data.map(item => {
                    return <Card key={item} data={item} />
                  })
                }
              </div>
            </div>
          </div>
          <div>
            <div className="flex justify-between items-center">
              <span className="md:text-[24px] text-[18px] font-medium text-[#050123]">Qarşıdan gələn hərraclar</span>
              <Link href='/' className="md:text-[18px] text-[16px] font-medium text-[#E70000]">Hamsı</Link>
            </div>
            <div className="overflow-auto">
              <div className="mt-[16px] flex justify-between gap-[32px] min-w-[1220px]">
                {
                  data.map(item => {
                    return <Card key={item} data={item} />
                  })
                }
              </div>
            </div>
          </div>
          <div>
            <div className="flex justify-between items-center">
              <span className="md:text-[24px] text-[18px] font-medium text-[#050123]">Tövsiyə olunanlar</span>
              <Link href='/' className="md:text-[18px] text-[16px] font-medium text-[#E70000]">Hamsı</Link>
            </div>
            <div className="overflow-auto">

              <div className="mt-[16px] flex justify-between gap-[32px] min-w-[1220px]">
                {
                  data.map(item => {
                    return <Card key={item} data={item} />
                  })
                }
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="py-[120px] ">
        <div className="w-full md:flex-row flex-col bg-[#FFFDEF] md:ps-[80px] flex items-center gap-x-[50px]">
          <div className="py-[25px] md:px-0 px-[16px] md:w-[55%] w-full ">
            <div className="flex flex-col md:items-start items-center w-full">
              <span className="md:text-[36px] text-[24px] font-medium text-[#050123] ">İndi al</span>
              <p className="pt-[8px] md:text-[18px] text-[16px] text-[#828091] md:text-start text-center">Programınıza uyğun olaraq təsviri sənət, dekorativ əşyalar, zərgərlik və saatlar alın və ya satın</p>
            </div>
            <div className="md:mt-[36px] mt-[30px] mb-[15px] flex md:justify-start justify-center">
              <Link href='/profile/activity-harrac' className="px-[26px] py-[13px] border-[1px] bg-[#04011B] rounded-[8px] md:text-[20px] text-[18px] font-medium  text-[#FFFDEF] ">Şəxsi satışlara baxın</Link>
            </div>
          </div>
          <div className="md:w-[45%] w-full h-[100%]">
            <Image src={nowBuy} alt="Now buy" className="w-full md:h-[288px] h-[250px]" />
          </div>
        </div>
      </div>
      {/* <div className="lg:px-[80px] md:px-[50px] px-[16px] py-[60px]">
        <div className="flex flex-col items-center">
          <span className="md:text-[36px] text-[24px] font-semibold text-[#050123] ">Haqqımızda Dedikləri</span>
          <p className="pt-[10px] md:text-[18px] text-[16px] font-medium text-[#828091] md:w-[70%] mx-auto text-center">Növbəti hərracı hara etməyi qərar vermık üçün HERRAC.ORG vebsaytından istifadə edən istifadəçilərin rəyləri ilə maraqlanırsınız? Gəlin aşağıda yoxlayın!</p>
        </div>
        <div className="py-[60px] grid lg:rid-cols-3 md:grid-cols-3 justify-between gap-[32px] ">
          {
            aboutData.map(item => {
              return <AboutCard key={item} />
            })
          }
        </div>
        <div className="flex justify-center">
          <Link href='/about' className="py-[12px] px-[46px] md:text-[#1ea59a] text-[#fff] md:text-[24px] text-[18px] font-medium border-[2px] border-[#1ea59a] rounded-[8px] md:bg-transparent bg-[#1ea59a] ">Daha çox</Link>
        </div>
      </div> */}
      <div className="pt-[77px] ">
        <div className="relative flex justify-center items-center">
          <Image src={infoImg} alt="" className="absolute left-0 top-0 h-full z-[-1] " />
          <div className="py-[40px] flex flex-col items-center bg-[#000] w-full bg-opacity-50">
            <span className="md:text-[44px] text-[24px] font-bold text-[#fff] md:w-[60%] mx-auto text-center">Yeniliklərdən anında xəbərdar olmaq üçün abunə olun</span>
            <div className="py-[7px] pe-[7px] ps-[18px] bg-[#fff] rounded-[8px] flex items-center justify-between md:mt-[40px] mt-[30px] max-w-[400px]">
              <input type="email" id="email" placeholder="E-mailinizi daxil edin" className="outline-none text-[#828091]" />
              <button className="px-[18px] py-[9px] bg-[#E70000] rounded-[4px] text-[#fff] font-medium">Abonə ol</button>
            </div>
          </div>
        </div>
      </div>
      <div className="md:px-[80px] px-[16px] py-[120px] bg-[#fff] grid lg:grid-cols-4 md:grid-cols-2  gap-[32px] ">
        <IndicatorCard img={indicatorIcon1} number="1000+" text="Xoşbəxt Müştəri" />
        <IndicatorCard img={indicatorIcon2} number="100+" text="Təqdirəlayiq rəylər" />
        <IndicatorCard img={indicatorIcon3} number="100+" text="Qalib Müştəri" />
        <IndicatorCard img={indicatorIcon4} number="100+" text="Yeni Şərhlər" />
      </div>
    </div>
  );
}
