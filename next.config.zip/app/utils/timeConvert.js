

export function timeConvert(secondDate){
    const now = new Date()
    const range = new Date(secondDate) - now
    
    const convertedDate = dateConvert(secondDate)

    if(range <=0 ){
       return { second: 0, minute: 0, hour: 0, day: 0 };
    }
    const second = Math.floor((range / 1000) % 60);
    const minute = Math.floor((range / (1000 * 60)) % 60);
    const hour = Math.floor((range / (1000 * 60 * 60)) % 24);
    const day = Math.floor(range / (1000 * 60 * 60 * 24));

    return {second, minute, hour, day, bestFormat: convertedDate}
}


export function dateConvert(secondDate) {
    const date = new Date(secondDate);


    const months = ["Yanvar", "Fevral", "Mart", "Aprel", "May", "Iyun", "Iyul", "Avqust", "Sentyabr", "Oktyabr", "Noyabr", "Dekabr"];
    const year = date.getFullYear();
    const month = months[date.getMonth()];
    const day = date.getDate();
    const hour = date.getHours();
    const minute = date.getMinutes();

    return `${day} ${month} ${year}-ci il, saat ${hour}:${minute < 10 ? '0' + minute : minute}`;
}