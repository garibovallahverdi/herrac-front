export async function fetchProductImagesById(productId){
    try {
        const res = await fetch(`${process.env.API_URL}/product-image?product=${productId}`, {
            method: "GET"
        });
        const productImage = await res.json();
        return productImage
        
    } catch (error) {
        throw error
    }
}