import axios from "axios";
import { fetchProductImagesById } from "./imageUtil";
import { fetchUserById } from "./userUtil";


export async function fetchProduct() {

    try {
        const res = await fetch(`http://localhost:9000/lot/getlot-byid`, {
            method: "GET"
        });
        const data = await res.json();

        
 
        const products = [];

        for (const product of data.content) {
            const productId = product.id;
            const userId = product.profile.id;

            const productImage = await fetchProductImagesById(productId)
            // const userInfo = await fetchUserById(userId)
 
            const images = productImage.content.map(img => img.image.downloadUrl);
            const productData = { ...product, /*user:userInfo*/  image: images };

            products.push(productData);
        }

        return products;
        
    } catch (error) {
        throw error
    }
}


export async function fetchProductById(id){
    try {
        const res = await axios.get(`http://localhost:9000/lot/getlot-byid/${id}`)
        const data = await res.json()

        const productId = data.id;
        const userId = data.profile.id;
        const productImage = await fetchProductImagesById(productId)
        // const userInfo = await fetchUserById(userId)

        const images = productImage.content.map(img => img.image.downloadUrl);
        
        let result = {...data, /*user:userInfo*/  image: images,  }
     
        return data
        
    } catch (error) {
        throw error
    }

}