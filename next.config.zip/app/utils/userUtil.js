// export async function fetchUserById(userId){
//     try{
//         const res = await fetch(`https://project-8c0cc1.apibrew.io:8443/profile/${userId}`, {
//             method: "GET"
//         })
//         const userInfo = await res.json()
//         console.log(userInfo);
//         return userInfo

//     }catch(error){
//         throw error
//     }
// }