'use client'
import React from 'react'
import checkLogo from '../../public/imgs/checkLogo.png'
import Image from 'next/image'
import { useRouter } from 'next/navigation'
const page = () => {

    const router = useRouter()

  return (
    <div className='w-full h-full flex justify-center items-center flex-col py-3'>
        <Image src={checkLogo} width={400} height={400}/>
        <p className='text-xl font-semibold'>Check your email and confirm account</p>
    </div>
  )

}

export default page