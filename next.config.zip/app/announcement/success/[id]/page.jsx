import React from 'react'

const page = () => {
  return (

    <div className='py-10 '>
        Success
      
    
    </div>
  )
}

export default page