'use client'
import Image from 'next/image'
import { useRouter  } from 'next/navigation'
import Link from 'next/link'
import React, { useEffect, useRef, useState } from 'react'
import backIcon from '../../public/svgs/back-icon.svg'
import addIcon from '../../public/svgs/add-icon.svg'
import '../../public/css/style.css'
import trash from '../../public/svgs/trash.svg'
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import TimePicker from 'react-time-picker';
import 'react-time-picker/dist/TimePicker.css';
import { useSelector } from 'react-redux'
import axios from 'axios'
const page = () => {
    const fileInputRef = useRef(null);
    


    const router = useRouter()
    const [dataImage, setDataImage] = useState('');
    const [loading,setLoading] = useState(false)
    const userReducer = useSelector(state=>state.user)
    const [lotInfo,setLotInfo] = useState({
        startTime:"",
        lotName:'',
        ownerName:"",
        startPrice:"",
        detailsText:"",
        location:""
    })
    const [formValues,setFormValues] = useState({
        manufacturer:'',
        brand:'', 
        model:'',
        year:'',
        vehicleType:'',
        color:'',
        mileage:'',
        engineCapacity:'',
        carSegments:'',
        driveType:'',
        engine:'',
        transmission:'',
        fuelType:'',
        brakeSystem:'',
    })
 const [formDetails, setFormDetails] = useState({
    files: []
  });
  const [imagePreviews, setImagePreviews] = useState([]);
    const handleDivClick = () => {
        if (!imagePreviews.length >0) {
          fileInputRef.current.click();
        }
      };
      
    const setDataCar = (e)=>{
      const { name, value } = event.target;
      setFormValues(prevState => ({
        ...prevState,
        [name]: value
      }));
    }
    console.log(lotInfo.startTime);
      const createISOString = (date, time) => {
        if (!date || !time) return '';
        const [hours, minutes] = time.split(':');
        const updatedDate = new Date(date);
        updatedDate.setHours(hours);
        updatedDate.setMinutes(minutes);
        console.log(updatedDate);
        return updatedDate;
      };
    
     
    
    
   
      const handleFileChange = (e) => {
        const files = Array.from(e.target.files);
        const newFiles = [...formDetails.files, ...files];
        setFormDetails({ ...formDetails, files: newFiles });
    
        // Create image previews
        const newPreviews = files.map(file => URL.createObjectURL(file));
        setImagePreviews(prev => [...prev, ...newPreviews]);
       
    };
 
   
    const handleRemoveImage = (index) => {
      const newFiles = formDetails.files.filter((_, i) => i !== index);
      const newPreviews = imagePreviews.filter((_, i) => i !== index);
      setFormDetails({ ...formDetails, files: newFiles });
      setImagePreviews(newPreviews);
    };
    const setLotInfoFunc = (e)=>{
        const { name, value } = event.target;
        setLotInfo(prevState => ({
          ...prevState,
          [name]: value
        }));

        console.log(lotInfo);
    }

    const sumbitLot =async ()=>{
        const emptyFields = [];
        for (const [key, value] of Object.entries(formValues)) {
            if (value.trim() === '') {
              emptyFields.push(key);
            }
          }

          for (const [key, value] of Object.entries(lotInfo)) {
            if (value.trim() === '') {
              emptyFields.push(key);
            } 
          }
          if (emptyFields.length > 0) {
            alert(`Aşağıdaki alanlar doldurulmalıdır: ${emptyFields.join(', ')}`);
            return;
          }
      const formData = new FormData()   
      formDetails.files.forEach((file) => {
        formData.append('lotImages', file);
      });
      formData.append('startTime', lotInfo.startTime)
      formData.append('lotName', lotInfo.lotName)
      formData.append('ownerName', lotInfo.ownerName)
      formData.append('location', lotInfo.location)
      formData.append('startPrice', lotInfo.startPrice)
      formData.append('ownerId', userReducer.user.id)
      formData.append('detailsText', lotInfo.detailsText)
      formData.append('featuresDeatils', JSON.stringify(formValues));
      setLoading(true)
      axios.post('http://localhost:9000/lot/add-lot',formData,{
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })
      .then(res=>{
        console.log(res.data);
        setLoading(false)
        router.push(`offer/${res.data?.newLot?.id}`);
      })
      .catch(err=>{ 
        console.log(err); 
        setLoading(false)

      }) 
      console.log("FormData", formData.lotImages);
      for (let pair of formData.entries()) {
        console.log(pair[0] + ': ' + pair[1]);
      }

      
    }

    const [date, setDate] = useState();
    const [time, setTime] = useState();
    const [formattedDateTime, setFormattedDateTime] = useState('');
  
    const convertToISO8601=(dateString, timeString) =>{
      // dateString "YYYY-MM-DD" formatında, timeString "HH:00" formatında olmalıdır
      const localDateTimeString = `${dateString}T${timeString}:00`;
      const localDate = new Date(localDateTimeString);
      const timezoneOffset = localDate.getTimezoneOffset();

      // Bu farkı saate ekle
      localDate.setMinutes(localDate.getMinutes() - timezoneOffset);
      // Tarih ve saat bilgisini UTC formatına çevir
      const utcDateString = localDate.toISOString();
    
      return utcDateString;
    }
   
    const handleConvert = () => {
      const result = convertToISO8601(date, time);
      setFormattedDateTime(result);
      console.log(result);
    };
  
    const generateHourOptions = () => {
      const hours = [];
      for (let i = 0; i < 24; i++) {
        const hour = i.toString().padStart(2, '0');
        for (let j = 0; j < 60; j += 15) {
          const minute = j.toString().padStart(2, '0');
          hours.push(<option key={`${hour}:${minute}`} value={`${hour}:${minute}`}>{`${hour}:${minute}`}</option>);
        }
      }
      return hours;
    };

    const setDateFunc = (e)=>{
      setDate(e.target.value)
  }
    const setTimeFunc = (e)=>{
      setTime(e.target.value)
    }

    useEffect(() => {
      if (date && time) {
        const result = convertToISO8601(date, time);
        setFormattedDateTime(result);
        setLotInfo(prev=>({
          ...prev,
          startTime:result
        }))
      }
    }, [date, time]);

    return (
        <div className='w-full max-w-[1500px] mx-auto relative'>
          {loading &&
            <div className='overlay'>
              <div className='spinner'></div>
            </div>
}
            <div className='flex justify-between items-center md:px-[80px] px-[16px] py-[23px] border-b-[1px] border-[#D9D9DE]'>
                <div className='flex items-center gap-[5px]'>
                    <span className='md:text-[18px] text-[16px] font-medium text-[#050123]'>Ana səhifə</span>
                    <span className='md:text-[18px] text-[16px] font-medium text-[#050123]'>/</span>
                    <span className='md:text-[18px] text-[16px] font-medium text-[#050123]'>Hərrac elan et</span>
                </div>
                <Link href='/' className='flex items-center gap-[5px]'>
                    <Image src={backIcon} alt='back icon' />
                    <span className='md:text-[16px] text-[14px] font-medium text-[#050123]'>Geri</span>
                </Link>
            </div>
            <div className='md:px-[80px] px-[16px] md:py-[100px] py-[50px]'>
                <div className='flex flex-col items-center'>
                    <span className='text-[16px] text-[#E70000]'>Vaxt itirmədən indi başla</span>
                    <span className='md:text-[32px] text-[24px] font-medium text-[#050123] text-center'>HƏRRAC.ORG Hərrac: Unikal Fürsətləri Qaçırmayın!</span>
                    <p className='md:text-[18px] text-[16px] text-[#44415a] mt-[16px] text-center'>Hərrac keçirməklə özəl məhsulları sərfəli qiymətlərlə satmaq şansınız var, mövcud fürsətlərdən dəyərləndirin.</p>
                </div>
                <div className='grid md:grid-cols-2 gap-x-[32px] gap-y-[48px] md:mt-[100px] mt-[50px]'>
                <div className='flex flex-col'>
                        <label htmlFor="lotName" className='md:text-[18px] text-[16px] text-[#44415a]'>Herracin adi</label>
                        <input value={lotInfo.lotName}  onChange={(e)=>setLotInfoFunc(e)} name='lotName' type="text" id='lotName' 
                        placeholder='Seçin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="ownerName" className='md:text-[18px] text-[16px] text-[#44415a]'>Herrac Sahibinin adi</label>
                        <input value={lotInfo.ownerName}  onChange={(e)=>setLotInfoFunc(e)} name='ownerName' type="text" id='ownerName' 
                        placeholder='Seçin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="startPrice" className='md:text-[18px] text-[16px] text-[#44415a]'>Lotun baslangic qiymeti</label>
                        <input value={lotInfo.startPrice}  onChange={(e)=>setLotInfoFunc(e)} name='startPrice' type="text" id='startPrice' 
                        placeholder='Seçin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="manufacturer" className='md:text-[18px] text-[16px] text-[#44415a]'>İstehsalçı</label>
                        <input value={formValues.manufacturer}  onChange={(e)=>setDataCar(e)} name='manufacturer' type="text" id='manufacturer' 
                        placeholder='Seçin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="brand" className='md:text-[18px] text-[16px] text-[#44415a]'>Marka</label>
                        <input value={formValues.brand}  onChange={(e)=>setDataCar(e)} name='brand' type="text" id='brand' 
                        placeholder='Seçin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                   
                    <div className='flex flex-col'>
                        <label htmlFor="model" className='md:text-[18px] text-[16px] text-[#44415a]'>Model</label>
                        <input value={formValues.model}  onChange={(e)=>setDataCar(e)} name='model' type="text" id='model' 
                        placeholder='Modelini daxil edin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                   
                    <div className='flex flex-col'>
                        <label htmlFor="year" className='md:text-[18px] text-[16px] text-[#44415a]'>Ili</label>
                        <input  value={formValues.year}  onChange={(e)=>setDataCar(e)} name='year' type="text" id='year' 
                        placeholder='Ili daxil edin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                    <div className='flex flex-col'>
                    <label htmlFor="vehicleType" className='md:text-[18px] text-[16px] text-[#44415a]'>Kategoriya</label>
                        <select  onChange={(e)=>setDataCar(e)} name="vehicleType" id="vehicleType"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="Benzin">Sedan</option>
                            <option value="Dizel">Jeep</option>
                        </select>
                    </div>
                    <div className='flex flex-col'>
                    <label htmlFor="location" className='md:text-[18px] text-[16px] text-[#44415a]'>Mekan</label>
                        <select  onChange={(e)=>setLotInfoFunc(e)} name="location" id="location"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="Benzin">Baki</option>
                            <option value="Dizel">Sumqayit</option>
                        </select>
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="fuelType" className='md:text-[18px] text-[16px] text-[#44415a]'>Yanacaq növü</label>
                        <select   onChange={(e)=>setDataCar(e)} name="fuelType" id="fuelType"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="Benzin">Benzin</option>
                            <option value="Dizel">Dizel</option>
                            <option value="Qaz">Qaz</option>
                            <option value="Elektro">Elektro</option>
                            <option value="Hibrid">Hibrid</option>
                            <option value="Plug-in Hibrid">Plug-in Hibrid</option>
                        </select>
                    </div> 
                    <div className='flex flex-col'>
                        <label htmlFor="color" className='md:text-[18px] text-[16px] text-[#44415a]'>Rəng</label>
                        <select   onChange={(e)=>setDataCar(e)} name="color" id="color"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="Qara">Qara</option>
                            <option value="Ağ">Ağ</option>
                            <option value="Göy">Göy</option>
                            <option value="Qırmızı">Qırmızı</option>
                            <option value="Yaşıl">Yaşıl</option>
                            <option value="Sarı">Sarı</option>
                            <option value="Turuncu">Turuncu</option>
                            <option value="Digər">Digər</option>
                        </select>
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="carSegments" className='md:text-[18px] text-[16px] text-[#44415a]'>Avtomobil seqmenti</label>
                        <select  onChange={(e)=>setDataCar(e)} name="carSegments" id="carSegments"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="Luks">Luks</option>
                            <option value="Luks1">Luks1</option>
                            <option value="Luks2">Luks2</option>
                            <option value="Luks3">Luks3</option>
                            <option value="Luks4">Luks4</option>
                        </select>
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="mileage" className='md:text-[18px] text-[16px] text-[#44415a]'>Kilometr</label>
                        <input value={formValues.mileage}  onChange={(e)=>setDataCar(e)} name='mileage' type="number" id='mileage' min={0}
                        placeholder='Kilometri daxil edin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="engineCapacity" className='md:text-[18px] text-[16px] text-[#44415a]'>Muherrikin Hecmi</label>
                        <input value={formValues.engineCapacity}  onChange={(e)=>setDataCar(e)} name='engineCapacity' type="number" id='engineCapacity' min={0}
                        placeholder='Muherrikin hecmi'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                    <div className='flex flex-col'>
                        <label htmlFor="transmission" className='md:text-[18px] text-[16px] text-[#44415a]'>Ötürücü</label>
                        <select  onChange={(e)=>setDataCar(e)} name="transmission" id="transmission"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="Arxa">Avtomat</option>
                            <option value="Ön">Mexanik</option>
                        </select>
                    </div>

                    <div className='flex flex-col'>
                        <label htmlFor="driveType" className='md:text-[18px] text-[16px] text-[#44415a]'>Cekis</label>
                        <select onChange={(e)=>setDataCar(e)} name="driveType" id="driveType"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="Arxa">On ceker </option>
                            <option value="Ön">Arxa ceker</option>
                        </select>
                    </div>
                  
                    <div className='flex flex-col'>
                        <label htmlFor="engine" className='md:text-[18px] text-[16px] text-[#44415a]'>At gucu</label>
                        <input value={formValues.engine}  onChange={(e)=>setDataCar(e)} name='engine' type="text" id='engine' 
                        placeholder='At gucunu daxil edin'
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'
                        />
                    </div>
                   
                  
                    <div className='flex flex-col'>
                        <label htmlFor="brakeSystem" className='md:text-[18px] text-[16px] text-[#44415a]'>Eylec sistemi</label>
                        <select   onChange={(e)=>setDataCar(e)} name="brakeSystem" id="brakeSystem"
                        className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'>
                            <option value disabled selected>Seçin</option>
                            <option value="ABŞ">ABS - Anti-lock Braking System</option>
                            <option value="Avropa">EBD - Electronic Brakeforce Distribution</option>
                            <option value="Koreya">ESC - Electronic Stability Control</option>
                            <option value="Yaponiya">TCS - Traction Control System</option>
                            <option value="Rəsmi Distribyutor">Rəsmi Distribyutor</option>
                            <option value="Rusiya">BA - Brake Assist</option>
                            <option value="Digər">EPB - Electronic Parking Brake</option>
                            <option value="Digər">CBC - Cornering Brake Control</option>
                            <option value="Digər">HBA - Hydraulic Brake Assist</option>
                            <option value="Digər">DSC - Dynamic Stability Control</option>
                            <option value="Digər">DBC - Dynamic Brake Control</option>
                        </select>
                    </div>
                  
                   
                </div>
                <div>
                <div className='flex mt-5 flex-col gap-2'>
                    <p className='w-full text-xl font-semibold'>Baslama tarixini planlayin.</p>
                    
                    <div>
      <input
        type="date"
        value={date}
        onChange={(e) => setDateFunc(e)}
      />
      <select
        value={time}
        onChange={(e) => setTimeFunc(e)}
      >
        <option value="">Select Time</option>
        {generateHourOptions()}
      </select>
      {formattedDateTime && (
        <div>
          <h2>Formatted DateTime:</h2>
          <p>{formattedDateTime}</p>
        </div>
      )}
    </div>
                    </div>
                </div>
                <div className='my-[48px] flex flex-col'>
                    <label htmlFor="detailsText" className='md:text-[18px] text-[16px] text-[#44415a]'>Hərracın detayları</label>
                    <textarea value={lotInfo.detailsText} onChange={(e)=>setLotInfoFunc(e)} name='detailsText' id="detailsText" cols="30" rows="7" className='px-[20px] py-[16px] mt-[10px] outline-none border-[1px] border-[#C1BFC8] rounded-[8px] md:text-[16px] text-[14px]'></textarea>
                </div>
                <div>

                    <span className='text-[18px] text-[#44415a] '>Hərracın şəkilləri</span>
                    <div    onClick={handleDivClick} className='my-[10px] p-[40px] flex items-center gap-x-[40px] border-[1px] border-[#C1BFC8] rounded-lg'>
                         <input multiple ref={fileInputRef}   onChange={handleFileChange} type="file" className='hidden' />
                         {
                            imagePreviews.length >0 && imagePreviews.map((image,index)=>(
                                <div id={image.id} className='relative w-[150px] h-[150px]  border-2 border-black'>
                                <div onClick={() => handleRemoveImage(index)} className='absolute w-[30px] h-[30px] right-1 '>
                                  <Image src={trash} className='w-full object-cover h-full'/>
                                </div>
                                <img src={image}  className='w-full h-full m-[2px] object-cover'/>
                           </div>

                            ))
                         }
                        
                    </div>
                    <span className='text-[18px] text-[#44415a] '>Minimum - ön, arxa və daxili şəkillər məcburidir.   Optimal ölçü - 1024x768.</span>
                </div>
                <div className='mt-[50px]'>
                    <button onClick={sumbitLot} className='px-[63px] py-[15px] bg-[#E70000] rounded-[8px] md:text-[18px] text-[16px] text-[#fff] font-medium'>Elan et</button>
                </div>
            </div>
        </div>
    )
  }
export default page
