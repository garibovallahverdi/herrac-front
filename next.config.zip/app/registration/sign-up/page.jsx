 'use client'
import Image from 'next/image'
import Link from 'next/link'
import React, { useState } from 'react'
import backIcon from '../../../public/svgs/back-icon.svg'
import GoogleAuthButton from '@/components/googleAuthButton'
import axios from 'axios'
import '../../../public/css/style.css'
import { useRouter } from 'next/navigation'
const page = () => {
    const [registerData,setRegisterData] = useState({
        first_name:"",
        last_name:"",
        email:"",
        password:""

    })
    const router = useRouter()
    const [loading,setLoading] = useState(false)

    const getRegisterFormData = (e)=>{
        const { name, value } = event.target;
        setRegisterData(prevState => ({
          ...prevState,
          [name]: value
        }));

    }
   const onSubmit=()=>{
    setLoading(true)
    axios.post('http://localhost:9000/auth/register',registerData)
    .then(res=>{
        console.log(res.data);
        setLoading(false)
        router.push('/confirmmsg')

    })
    .catch(err=>{
        setLoading(false)
        
        console.log(err);
    })
   }
    return (
        <div className=''>
    
            <Link href='/' className='flex items-center gap-[5px]'>
                <Image src={backIcon} alt='back icon' />
                <span className='text-[16px] font-medium text-[#050123]'>Geri</span>
            </Link>
            <div className='my-[50px] md:flex md:justify-between  md:items-start'>
                <div className='flex justify-between  md:flex md:flex-col'>
                    <span className='text-[24px] font-semibold text-[#050123]'>Hesab yarat</span>
                    <span className='text-[14px] text-[#44415a] mt-[5px]'>Biznes və ya fərdi</span>
                </div>
                <div className='hidden md:block'>
                    <span className='text-[28px] font-extrabold text-[#e70000]'>HƏR</span>
                    <span className='text-[28px] font-extrabold text-[#050123]'>RAC.ORG</span>
                </div>
                </div>
                {loading &&
            <div className='overlay'>
              <div className='spinner'></div>
            </div>
}
            <div className='flex flex-col md:grid md:grid-cols-2 md:gap-x-[45px] md:gap-y-[40px] gap-y-[30px]'>
                
                <div className='flex flex-col'>
                    <label htmlFor="first_name" className='text-[16px] text-[#44415a]'>Ad</label>
                    <input value={registerData.first_name} onChange={(e)=>getRegisterFormData(e)} name='first_name' type="text" id='first_name' className='border-[1px] border-[#c1bfc8] mt-[5px] outline-none rounded-[8px] px-[16px] py-[10px] text-[15px]' />
                </div>
                <div className='flex flex-col'>
                    <label htmlFor="last_name" className='text-[16px] text-[#44415a]'>Soyad</label>
                    <input value={registerData.last_name} onChange={(e)=>getRegisterFormData(e)} name='last_name' type="text" id="last_name" className='border-[1px] border-[#c1bfc8] mt-[5px] outline-none rounded-[8px] px-[16px] py-[10px] text-[15px]' />
                </div>
                <div className='flex flex-col'>
                    <label htmlFor="email" className='text-[16px] text-[#44415a]'>E-poçt</label>
                    <input value={registerData.email} onChange={(e)=>getRegisterFormData(e)} name='email' type="email" id="email" className='border-[1px] border-[#c1bfc8] mt-[5px] outline-none rounded-[8px] px-[16px] py-[10px] text-[15px]' />
                </div>
                
                <div className='flex flex-col'>
                    <label htmlFor="password" className='text-[16px] text-[#44415a]'>Şifrə</label>
                    <input name="password" value={registerData.password} onChange={(e)=>getRegisterFormData(e)} type="password" id='password' className='border-[1px] border-[#c1bfc8] mt-[5px] outline-none rounded-[8px] px-[16px] py-[10px] text-[15px]' />
                </div>
            </div>
            <div className='my-[31px] flex items-center gap-[8px]'>
                <input type="checkbox" id="razi" className='w-[16px] h-[16px] cursor-pointer'/>
                <label htmlFor="razi" className='text-[12px] cursor-pointer'>
                    Mən bütün <Link href='/' className='text-[#1ea59a]'>Şərtlər</Link> və <Link href='/' className='text-[#1ea59a]'>Məxfilik siyasəti</Link> ilə razıyam
                </label>
            </div>
            <div className='flex flex-col md:grid md:grid-cols-2 md:gap-[45px]'>
                <button onClick={onSubmit} className='bg-[#04011B] rounded-[8px] w-full text-[16px] py-[10px] font-semibold text-[#fff]'>
                Qeydiyyat
                </button>
                <GoogleAuthButton/>
            </div> 
            <div className='mt-[28px] flex items-center justify-center gap-[5px]'>
                <span className='text-[16px] text-[#2b2b2b]'>Artıq hesabınız var?</span>
                <Link href='/registration' className='text-[#e70000] text-[16px]'>Daxil ol</Link>
            </div>
        </div>
    )
}

export default page
