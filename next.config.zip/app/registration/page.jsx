'use client'
import React, { useState } from 'react'
import backIcon from '../../public/svgs/back-icon.svg'
import Image from 'next/image'
import Link from 'next/link'
import GoogleAuthButton from '@/components/googleAuthButton'
import axios from 'axios'
import { useRouter } from 'next/navigation'
import '../../public/css/style.css'
import { useDispatch } from 'react-redux'
import { addUser } from '../redux/userSlice'
const page = () => {
    const [loginFormData,setLoginFormData] = useState({
        email:"",
        password:""
    })
    const dispatch = useDispatch()
    const [loading,setLoading] = useState(false)
 const router = useRouter()
    const onInputChange=  (e)=>{
        const { name, value } = event.target;

        setLoginFormData(prevState => ({
            ...prevState,
            [name]: value
          }));
          console.log(loginFormData);
    }
    const onSubmitLogin = async ()=>{
        setLoading(true)
        axios.post('http://localhost:9000/auth/login',{email:loginFormData.email,password:loginFormData.password},{ withCredentials: true })
        .then(res=>{
            console.log(res.data);
            dispatch(addUser(res.data))
                setLoading(false)
            // setInterval(()=>{
                router.push('/')
            // },1000)
    
        })
        .catch(err=>{
            setLoading(false)
            
            console.log(err);
        })
       }

    return (
        <div>
            <Link href='/' className='flex items-center gap-[5px]'>
                <Image src={backIcon} alt='back icon' />
                <span className='text-[16px] font-medium text-[#050123]'>Geri</span>
            </Link>
            <div className='my-[50px] md:flex md:justify-between  md:items-start'>
            {loading &&
            <div className='overlay'>
              <div className='spinner'></div>
            </div>
}
                <div className='flex justify-between  md:flex md:flex-col '>
                    <span className='text-[24px] font-semibold text-[#04011B]'>Daxil ol</span>
                    <span className='text-[14px] text-[#44415a] mt-[5px]'>Biznes və ya fərdi</span>
                </div>
                <div className='hidden md:block'>
                    <span className='text-[28px] font-extrabold text-[#e70000]'>HƏR</span>
                    <span className='text-[28px] font-extrabold text-[#050123]'>RAC.ORG</span>
                </div>
            </div>
            <div className=' flex flex-col md:grid md:grid-cols-2 md:gap-x-[45px] md:gap-y-[40px] mt-[45px]'>     
                <div className='flex flex-col'>
                    <label htmlFor="email" className='text-[16px] text-[#44415a]'>E-poçt</label>
                    <input onChange={(e)=>onInputChange(e)} value={loginFormData.email} name='email' type="email" id="email" className='border-[1px] border-[#c1bfc8] mt-[5px] outline-none rounded-[8px] px-[16px] py-[10px] text-[15px]' />
                </div>
                <div className='flex flex-col'>
                    <label htmlFor="password" className='text-[16px] text-[#44415a]'>Şifrə</label>
                    <input onChange={(e)=>onInputChange(e)} value={loginFormData.password} name='password' type="password" id='password'  className='border-[1px] border-[#c1bfc8] mt-[5px] outline-none rounded-[8px] px-[16px] py-[10px] text-[15px]'/>
                </div>
            </div>
            <div className='mt-[16px] flex justify-between items-center'>
                <div className='flex items-start gap-[8px]'>
                    <input type="checkbox" id="Məni xatırla" className='w-[16px] h-[16px] cursor-pointer'/>
                    <label htmlFor="Məni xatırla" className='text-[12px] text-[#44415a] cursor-pointer'>Məni xatırla</label>
                </div>
                <Link href='/registration/forget' className='text-[12px] text-[#1ea59a]'>Şifrəni unutmusunuz?</Link>
            </div>
            <div className='mt-[60px] flex flex-col  md:grid  md:grid-cols-2  md:gap-[45px] '>
                <button onClick={onSubmitLogin} className='bg-[#04011b] rounded-[8px] w-full text-[16px] py-[10px] font-semibold text-[#fff] '>
                    Daxil ol
                </button>
                <GoogleAuthButton/>
            </div>
            <div className='mt-[28px] flex items-center justify-center gap-[5px]'>
                <span className='text-[16px] text-[#2b2b2b]'>Hesabınız yoxdur?</span>
                <Link href='/registration/sign-up' className='text-[16px] text-[#e70000]'>Qeydiyyatdan keçin</Link>
            </div>
        </div>
    )
}
export default page
