"use client"
import Image from 'next/image'
import Link from 'next/link'
import React, { useEffect, useState } from 'react'
import backIcon from '../../public/svgs/back-icon.svg'
import starGray from '../../public/svgs/star-gray.svg'
import downGray from '../../public/svgs/dawn-gray.svg'
import filterImg from '../../public/svgs/Filter.svg'
import goBack from '../../public/svgs/go-back.svg'
import Card from '@/components/card'
import '../../public/css/style.css'
import { fetchProduct } from '../utils/productUtil'
import axios from 'axios'



const page = (prop) => {
    const [category, setCategory] = useState(false)
    const [producer, setProducer] = useState(false)
    const [model, setModel] = useState(false)
    const [color, setColor] = useState(false)
    const [brand, setBrand] = useState(false)
    const [fuelType, setFuelType] = useState(false)
    const [engineVolume, setEngineVolume] = useState(false)
    const [horsepower, setHorsepower] = useState(false)
    const [gearType, setGearType] = useState(false)
    const [kilometers, setKilometers] = useState(false)
    const [city, setCity] = useState(false)
    const [year, setYear] = useState(false)
    const [price, setPrice] = useState(false)
    const [filter, setFilter] = useState(false)
    const [data, setData] = useState([]);
 const [waitLots,setWaitLots] =useState(false)
    useEffect(() => {
         const params = {
            limit:1,
            offset:1
         } 
         setWaitLots(false)
        axios.get('http://localhost:9000/lot/getall-lots')
        .then(res=>{
            console.log(res.data);
            setData(res.data)
         setWaitLots(true)

        })
        .catch(err=>{
         setWaitLots(true)
            console.log(err);
        })
    }, []);



    return (
        <div className='pb-[120px] max-w-[1500px] mx-auto w-full '>
            <div className='flex items-center justify-between xl:px-[80px] lg:px-[40px] md:px-[20px] px-[16px] py-[23px] border-b-[1px] border-[#D9D9DE]'>
                <div className='flex items-center gap-[5px]'>
                    <span className='md:text-[16px] text-[14px] font-medium text-[#050123]'>Ana səhifə</span>
                    <span className='md:text-[16px] text-[14px] font-medium text-[#050123]'>/</span>
                    <span className='md:text-[16px] text-[14px] font-medium text-[#050123]'>Məhsullar</span>
                </div>
                <Link href='/' className='flex items-center gap-[5px]'>
                    <Image src={backIcon} alt='back icon' />
                    <span className='md:text-[16px] text-[14px] font-medium text-[#050123]'>Geri</span>
                </Link>
            </div>
            <div className='xl:px-[80px] lg:px-[40px] md:px-[20px] px-[16px] flex md:flex-row flex-col items-start lg:gap-[32px] gap-[20px] mt-[30px]'>
                <div className='md:w-1/4 w-full'>
                    <div className='flex justify-between items-center'>
                        <span className='text-[16px] font-medium text-[#44415a]'>110 Məhsul</span>
                        <butto onClick={()=>setFilter(!filter)} className='md:hidden block cursor-pointer'>
                            <Image src={filterImg} alt='filter img' />
                        </butto>
                        <button className='text-[#1ea59a] font-medium text-[16px] underline md:block hidden'>Filteri təmizlə</button>
                    </div>
                    <div className={`md:mt-[32px] md:px-[15px] md:py-[5px] p-[16px] border-[1px] border-[#D9D9DE] rounded-lg md:relative fixed ${filter ? "left-0" : "left-[-100%]"} md:left-0 top-0 w-full h-full bg-[#fff] z-[999] md:z-10 duration-300`}>
                        <div className='md:hidden flex justify-end'>
                            <button onClick={()=>setFilter(!filter)} className=''>
                                <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 12 12" fill="none">
                                    <path d="M11 1L1 11M11 11L1 1" stroke="#04011B" stroke-width="2" stroke-linecap="round" />
                                </svg>
                            </button>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setCategory(!category)} className='flex items-center justify-between  '>
                                <span>Kategoriya</span>
                                <Image src={downGray} alt='icon' className={`${category ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${category ? "flex" : "hidden"} flex-col gap-[10px] mt-[8px] `}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Hamısı' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Hamısı" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Hamısı</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Trend' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Trend" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Trend</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Tövsiyə olunanlar' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Tövsiyə olunanlar" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Tövsiyə olunanlar</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Qarşıdan gələn hərraclar' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Qarşıdan gələn hərraclar" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Qarşıdan gələn hərraclar</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Motoriklet' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Motoriklet" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Motoriklet</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Rodster' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Rodster" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Rodster</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Universal' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Universal" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Universal</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Sedan' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Sedan" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Sedan</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Pikap' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Pikap" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Pikap</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Yük maşını' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Yük maşını" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Yük maşını</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Kupe' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Kupe" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Kupe</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setProducer(!producer)} className='flex items-center justify-between  '>
                                <span>İstehsalçı</span>
                                <Image src={downGray} alt='icon' className={`${producer ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${producer ? 'flex' : "hidden"} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Ford' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Ford" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Ford</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Toyota' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Toyota" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Toyota</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='BMW' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="BMW" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>BMW</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Aston Martin Lagonda Limited' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Aston Martin Lagonda Limited" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Aston Martin Lagonda Limited</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Digər' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Digər" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Digər</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setModel(!model)} className='flex items-center justify-between  '>
                                <span>Model</span>
                                <Image src={downGray} alt='icon' className={`${model ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${model ? "flex" : "hidden"} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Tesla Model S' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Tesla Model S" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Tesla Model S</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='BMW 3 Seriya' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="BMW 3 Seriya" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>BMW 3 Seriya</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Mercedes-Benz E-Class' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Mercedes-Benz E-Class" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Mercedes-Benz E-Class</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Ford Mustang' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Ford Mustang" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Ford Mustang</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Toyota Camry' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Toyota Camry" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Toyota Camry</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Honda Civic' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Honda Civic" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Honda Civic</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='DB11' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="DB11" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>DB11</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Digər' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Digər" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Digər</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setColor(!color)} className='flex items-center justify-between  '>
                                <span>Rəng</span>
                                <Image src={downGray} alt='icon' className={`${color ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${color ? "flex" : "hidden"} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Qara' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Qara" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Qara</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Ağ' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Ağ" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Ağ</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Göy' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Göy" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Göy</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Qırmızı' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Qırmızı" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Qırmızı</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Yaşıl' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Yaşıl" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Yaşıl</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Sarı' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Sarı" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Sarı</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Turuncu' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Turuncu" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Turuncu</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Digər' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Digər" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Digər</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setBrand(!brand)} className='flex items-center justify-between  '>
                                <span>Marka</span>
                                <Image src={downGray} alt='icon' className={`${brand ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${brand ? "flex" : "hidden"} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Aston Martin' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Aston Martin" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Aston Martin</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Tesla' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Tesla" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Tesla</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='BMW' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="BMW" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>BMW</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Mercedes-Benz' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Mercedes-Benz" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Mercedes-Benz</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Ford' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Ford" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Ford</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setFuelType(!fuelType)} className='flex items-center justify-between  '>
                                <span>Yanacaq növü</span>
                                <Image src={downGray} alt='icon' className={`${fuelType ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${fuelType ? "flex" : "hidden"} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Benzin' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Benzin" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Benzin</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Dizel' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Dizel" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Dizel</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Elektrik' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Elektrik" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Elektrik</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setEngineVolume(!engineVolume)} className='flex items-center justify-between  '>
                                <span>Mühərrik həcmi</span>
                                <Image src={downGray} alt='icon' className={`${engineVolume ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${engineVolume ? "flex" : "hidden"} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='3 - 6 litre' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="3 - 6 litre" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>3 - 6 litre</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='6 - 8 litre' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="6 - 8 litre" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>6 - 8 litre</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='8 - 10 litre' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="8 - 10 litre" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>8 - 10 litre</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setHorsepower(!horsepower)} className='flex items-center justify-between  '>
                                <span>At gücü</span>
                                <Image src={downGray} alt='icon' className={`${horsepower ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={` ${horsepower ? 'flex' : "hidden"} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='200 - 450 bg' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="200 - 450 bg" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>200 - 450 bg</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='450 - 700 bg' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="450 - 700 bg" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>450 - 700 bg</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='700 - 1000 bg' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="700 - 1000 bg" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>700 - 1000 bg</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setGearType(!gearType)} className='flex items-center justify-between  '>
                                <span>Ötürücü növü</span>
                                <Image src={downGray} alt='icon' className={`${gearType ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${gearType ? 'flex' : 'hidden'} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Arxa' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Arxa" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Arxa</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Ön' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Ön" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Ön</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Dörd' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Dörd" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Dörd</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setKilometers(!kilometers)} className='flex items-center justify-between  '>
                                <span>Kilometr</span>
                                <Image src={downGray} alt='icon' className={`${kilometers ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${kilometers ? 'flex' : 'hidden'} flex-col gap-[10px] mt-[8px]`}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Az (50.000 km və ya daha az)' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Az (50.000 km və ya daha az)" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Az (50.000 km və ya daha az)</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Orta (50.000 - 100.000 km)' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Orta (50.000 - 100.000 km)" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Orta (50.000 - 100.000 km)</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Çox (100.000 km-dən çox)' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Çox (100.000 km-dən çox)" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Çox (100.000 km-dən çox)</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setCity(!city)} className='flex items-center justify-between  '>
                                <span>Şəhər</span>
                                <Image src={downGray} alt='icon' className={`${city ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <ul className={`${city ? "flex" : "hidden"} flex-col gap-[10px] mt-[8px]  `}>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Hamısı' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Hamısı" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Hamısı</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Bakı' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Bakı" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Bakı</label>
                                </li>
                                <li className='flex items-center gap-[8px]'>
                                    <input type="checkbox" id='Sumqayıt' className='w-[20px] h-[20px] cursor-pointer' />
                                    <label htmlFor="Sumqayıt" className='cursor-pointer text-[16px] text-[#828091] selection:bg-none'>Sumqayıt</label>
                                </li>
                            </ul>
                        </div>
                        <div className='border-b-[1px] border-[#D9D9DE] py-[9px] cursor-pointer'>
                            <div onClick={() => setYear(!year)} className='flex items-center justify-between  '>
                                <span>İl</span>
                                <Image src={downGray} alt='icon' className={`${year ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <div className={`${year ? 'flex' : 'hidden'} gap-[5px] mt-[8px]`}>
                                <input type="date" name="" id="" className='border-[1px] border-[#000] px-[10px] py-[8px] rounded-md' />
                                <Image src={goBack} alt='icon' />
                                <input type="date" name="" id="" className='border-[1px] border-[#000] px-[10px] py-[8px] rounded-md' />
                            </div>
                        </div>
                        <div className='py-[9px] cursor-pointer'>
                            <div onClick={() => setPrice(!price)} className='flex items-center justify-between  '>
                                <span>Qiymət</span>
                                <Image src={downGray} alt='icon' className={`${price ? "rotate-180" : "rotate-0"} duration-300`} />
                            </div>
                            <div className={`${price ? 'flex' : "hidden"} gap-[5px] mt-[8px]`}>
                                <input type="number" name="" id="" placeholder='Min' className='text-center outline-none border-[1px] border-[#000] px-[10px] py-[8px] rounded-md w-1/2' />
                                <Image src={goBack} alt='icon' />
                                <input type="number" name="" id="" placeholder='Max' className='text-center outline-none border-[1px] border-[#000] px-[10px] py-[8px] rounded-md w-1/2' />
                            </div>
                        </div>
                        <div className='md:hidden flex justify-center'>
                            <button className='text-[14px] text-[#0684F8]'>Filteri təmizlə (Sıfırla)</button>
                        </div>
                    </div>
                </div>
                <div className='flex flex-col md:w-3/4 w-full'>
                    <div className='flex items-center md:justify-end justify-between gap-[32px]'>
                        <div className='flex items-center gap-[5px]'>
                            <span className='text-[16px] text-[#828091] font-medium'>Sevimli məhsullar</span>
                            <Image src={starGray} alt='star gray' />
                        </div>
                        <div className='flex items-center gap-[5px]'>
                            <span className='text-[16px] text-[#828091] font-medium'>Son əlavələr</span>
                            <Image src={downGray} alt='down gray' />
                        </div>
                    </div>
                    <div className='flex flex-wrap justify-center gap-[32px] mt-[32px] w-full'>
                        
                        { 


                            
                         waitLots?data.map(item => {
                                return <Card key={item.id} data={item}  />
                            }):<p>Loading</p>
                        }
                    </div>
                </div>
            </div>
        </div>
    )
}

export default page
