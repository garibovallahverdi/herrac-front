"use client";
import Image from "next/image";
import Link from "next/link";
import React, { useEffect, useState } from "react";
import backIcon from "../../../public/svgs/back-icon.svg";
import heartIcon from "../../../public/svgs/heart.svg";
import shareIcon from "../../../public/svgs/share.svg";
import { io } from 'socket.io-client';
import plus from "../../../public/svgs/minus.svg";
import minus from "../../../public/svgs/plus.svg";
import { fetchProduct, fetchProductById } from "@/app/utils/productUtil";

import Card from "@/components/card";
import { timeConvert } from "@/app/utils/timeConvert";
import CarsCard from "@/components/cars-card";
import OfferCard from "@/components/offer-card";
import axios from "axios";
import { useSelector } from "react-redux";
import Popup from "@/components/popUp";
import '../../../public/css/style.css'

const socket = io('http://localhost:9000');

export const calculateTimeLeft = (targetDate) => {
  const localDate = new Date(targetDate);
    const newLocalDate = localDate.getTime()
  const difference = new Date(newLocalDate) - new Date();
  let timeLeft = {};
 
  if (difference > 0) {
    timeLeft = {
      days: Math.floor(difference / (1000 * 60 * 60 * 24)),
      hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
      minutes: Math.floor((difference / 1000 / 60) % 60),
      seconds: Math.floor((difference / 1000) % 60),
      timeOff:false
    };
  } else {

    timeLeft = {
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
      timeOff:true

    };
  }

  return timeLeft;
};
const DetailPage = ({ params }) => {
  const [data, setData] = useState({});
  const [lastBid,setLastBid] = useState()
  const [lotStart,setLotStart] = useState(true)
  const [dir,setDirr] = useState('http://localhost:9000/upload/images/');
  const convertedDate = timeConvert(data.expire);
  const changedData = { ...data, expire: convertedDate };
  const {
    title,
    subtitle,
    description,
    currentBid,
    image,
    expire: { day, hour, minute, second, bestFormat },
  } = changedData;
 const userReducer = useSelector(state=>state.user)
  const [recommended, setRecommend] = useState([]);
  useEffect(() => {
     function getData() {
       axios.get(`http://localhost:9000/lot/getlot-byid/${params.id}`) 
      .then(res=>{
      setData({...res.data});
      })
    } 
     
    getData();
      
  }, []);
  useEffect(()=>{
    if(data.result){
      if(data?.result?.LotBids?.length>0){
        const maxItem = findMaxAmountItem(data.result.LotBids);
        setLastBid(maxItem)
      }else {
         setLastBid(data.result.startPrice)
      }

    socket.emit("joinLot",data.result.lotNumber)
    return () => {
      socket.off('joinLot');
    };
  }
   
},[data?.result]) 
const findMaxAmountItem = (items) => {
  return items.reduce((maxItem, currentItem) => 
    currentItem.bidAmount > maxItem.bidAmount ? currentItem : maxItem
  , items[0]);
};
  const [count, setCount] = useState(15000);

  const inCount = () => {
    setCount(count + 100);
  };

  const deCount = () => {
    setCount(count - 100);
  };
  const [bidTime,setBidTimer] =useState(false)
  const addBid = async ()=>{
    const newBid ={
      userId:userReducer.user?.id,
      bidAmount:lastBid.bidAmount+100 || data?.result?.startPrice + 100

    }
    try {
      
      await axios.post(`http://localhost:9000/bid/add-bid/${params.id}`,{...newBid})
      .then(res=>{
        // setLastBid(res.data.newBide.newBid.bidAmount)
        let newBid ={
          lotNumber:data.result.lotNumber,
          newBid:res.data.newBide.newBid

        }
        socket.emit('newBid',newBid)
      })
    } catch (error) {
      console.log(error); 
    }
  }
  // useEffect(() => {
  //   console.log('lastBid updated:', lastBid);
  // }, [lastBid]);


  useEffect(() => {
    // Join the room on component mount

    // Listen for new bids
    socket.on('receiveBid', (data) => {
      console.log('New bid received:', data);
      setData(prev=>({
        ...prev,
        result:{
          ...prev.result,
          LotBids:[data.newBid,...prev.result.LotBids]
        }
      }))
      setLastBid(data.newBid)
    });

    // Cleanup on component unmount
    return () => {
      socket.off('receiveBid');
    };
  }, [data]);

  const [showPopup, setShowPopup] = useState(false);

  const handleButtonClick = () => {
    setShowPopup(true);
  };

  const handleClosePopup = (confirmed) => {
    setShowPopup(false);
   if(confirmed){
   const sendData=  {
      userId:userReducer?.user.id
    }
    try {
      axios.post(`http://localhost:9000/lot/jointo-lotbidders/${params.id}`,{...sendData})
      .then(res=>{
        setData(prev=>({
          ...prev,
          result:{
            ...prev.result,
            bidders:[...res.data.lotBidders]
          }
        }))
      })
      
    } catch (error) {
       console.log(error);
    }
   }
  };
 

// calculate time
// const calculateTimeLeft = (targetDate) => {
//   const localDate = new Date(targetDate);
//     const newLocalDate = localDate.getTime()
//   const difference = new Date(newLocalDate) - new Date();
//   let timeLeft = {};
 
//   if (difference > 0) {
//     timeLeft = {
//       days: Math.floor(difference / (1000 * 60 * 60 * 24)),
//       hours: Math.floor((difference / (1000 * 60 * 60)) % 24),
//       minutes: Math.floor((difference / 1000 / 60) % 60),
//       seconds: Math.floor((difference / 1000) % 60)
//     };
//   } else {

//     timeLeft = {
//       days: 0,
//       hours: 0,
//       minutes: 0,
//       seconds: 0
//     };
//   }

//   return timeLeft;
// };
const [timeLeft, setTimeLeft] = useState(calculateTimeLeft(data.result?.startTime));

  useEffect(() => {
    const timer = setInterval(() => {
        setTimeLeft(calculateTimeLeft(data.result?.startTime))
        console.log(data.result?.startTime);

    }, 1000);

    return () => clearInterval(timer);
  });
  useEffect(()=>{
    if( timeLeft?.minutes == 0 && timeLeft?.seconds == 0 && timeLeft?.timeOff==true && data?.result?.status=='scheduled'){
      setData(prev=>({
        ...prev,
        result:{
          ...prev.result,
          status:'active',
        }
      }))
    }
  },[timeLeft])

  const [endTime,setEndTime] =useState()
  useEffect(() => {
    const timer = setInterval(() => {
       if(lastBid && data?.result?.status == 'active'){
        let utcTime = new Date(lastBid.createdAt);
     
        // Bir saat ekleme
        utcTime.setHours(utcTime.getHours() + 5);
        let localTime = utcTime.toISOString();
        setEndTime(calculateTimeLeft(localTime));
       
       }
       
   
    }, 1000);
   
    return () => clearInterval(timer);
  });


useEffect(()=>{
  if( endTime?.minutes == 0 && endTime?.seconds == 0 && endTime?.timeOff==true && data?.result?.status=='active'){
    setData(prev=>({
      ...prev,
      result:{
        ...prev.result,
        status:'completed',
        winnerUserId:lastBid?.userId,
        winnerBidId:lastBid?.id
      }
    }))

   }

},[endTime])

  if(!data.result){
    return <p>Loading.....</p>
  }
  return (
    <div className="max-w-[1500px] mx-auto w-full">
      <div className="flex justify-between items-center  px-[20px] md:px-[80px] py-[23px]  border-b-[1px] border-[#D9D9DE]">
        <div className="flex items-center  gap-[5px] mt-[20px] md:mt-[0px]">
          <span className="md:text-[16px] text-[14px] text-[#050123] font-medium">
            Ana səhifə
          </span>
          <span className="md:text-[16px] text-[14px] text-[#050123] font-medium">
            /
          </span>
          <span className="md:text-[16px] text-[14px] text-[#050123] font-medium">
            Təklif
          </span>
        </div>
        <Link  
          href="/"   
          className="flex items-center gap-[5px] mt-[20px] md:mt-[0px]"
        >
          <Image src={backIcon} alt="back icon" />
          <span className="md:text-[16px] text-[14px] font-medium text-[#050123]">
            Geri
          </span>
        </Link>
      </div>
      <div className="px-[20px] xl:px-[80px] lg:px-[50px] my-[50px] flex md:flex-row flex-col xl:gap-x-[32px] md:gap-x-[15px]">
        <div className="w-full md:w-1/2 flex md:flex-row flex-col-reverse md:gap-[32px] h-[400px]">
          <div className="flex md:flex-col flex-row justify-between  mt-[30px] md:mt-[0px] h-full   overflow-scroll gap-1 md lg:min-w-[77px] md:min-w-[65px]">
            {data?.result && data.result?.image?.map((item) => {
              return (
                <img
                  src={`http://localhost:9000/upload/images/${item}`}
                  alt={item}
                  className=" object-cover md:w-[77px] md:h-[77px] w-[65px] h-[65px]"
                />
              );
            })}
          </div>
          <div className="md:h-auto"> 
            {/* <Image src={offerImg5} alt='offer img'  /> */}
            {data?.result?.image  && (
              <img
                src={dir+data?.result?.image[0]}
                alt="offer img"
                className="object-cover w-[100%] h-[280px] md:w-[100%] md:h-[100%]"
              />
            )}
          </div>
        </div>
        <div className="mt-[30px] md:mt-[0px] md:w-1/2 w-full flex flex-col gap-[32px] md:gap-[20px]  ml-[0] md:ml-[20px]">
          <div>
            <span className="text-[24px] md:text-[32px] font-medium text-[#050123]">
              {data.result && "Lot# "+data?.result?.lotNumber +' '+ data.result.lotName}
            </span>
            <p className="mt-[8px] text-[16px] text-[#44415a]">{subtitle}text</p>

          {data?.result?.status == 'scheduled' &&
           <div className="flex md:flex-row flex-col items-center mt-[20px]">
              <div className="md:min-w-[80px] md:max-w-[80px] w-full h-[70px] shadow flex items-center justify-center border-[2px] border-[#FFCB21] border-dashed rounded-lg">
                <span className="text-center font-medium text-[#e70000] flex md:flex-col md:gap-0 gap-[5px] items-center justify-center"><span>Qalan</span><span>vaxt</span></span>
              </div>
              <div className="grid grid-cols-4 items-center justify-between gap-x-[24px] md:ms-[36px] w-full md:mt-0 mt-[15px]">
                <div className=" h-[70px] flex flex-col  items-center justify-center bg-[#fff] rounded-lg shadow">
                  <span className="mb-[-6px] text-[24px] font-bold text-[#04011b]">{timeLeft.days}</span>
                  <span className="text-[16px] text-[#04011b]">Gün</span>
                </div>
                <div className=" h-[70px] flex flex-col  items-center justify-center bg-[#fff] rounded-lg shadow">
                  <span className="mb-[-6px] text-[24px] font-bold text-[#04011b]">{timeLeft.hours}</span>
                  <span className="text-[16px] text-[#04011b]">Saat</span>
                </div>
                <div className=" h-[70px] flex flex-col  items-center justify-center bg-[#fff] rounded-lg shadow">
                  <span className="mb-[-6px] text-[24px] font-bold text-[#04011b]">{timeLeft.minutes}</span>
                  <span className="text-[16px] text-[#04011b]">Dəqiqə</span>
                </div>
                <div className=" h-[70px] flex flex-col  items-center justify-center bg-[#fff] rounded-lg shadow">
                  <span className="mb-[-6px] text-[24px] font-bold text-[#04011b]">{timeLeft.seconds}</span>
                  <span className="text-[16px] text-[#04011b]">Saniyə</span>
                </div>
              </div>
            </div>
}
{data?.result?.status == 'active' &&<p className="text-2xl text-[green] font-bold">Lot Aktivdir</p>}
{data?.result?.status == 'completed' &&<p className="text-2xl text-[red] font-bold">Lot Bitmisdir</p>}
            {
            timeLeft.timeOff == true && data?.result?.status == 'active' &&
            <div className="mt-[16px] flex items-center gap-[5px]">
              <span className="md:text-[16px] text-[14px] text-[#44415a]">Hərracın bitməsinə qalan vaxt:</span>
              {!endTime?.hours ==0 &&
              
              <span className="md:text-[16px] text-[14px]">
              <span className="text-[red]">{endTime?.hours }</span> saat
              </span>
              }
              {!endTime?.minutes ==0 &&
              
              <span className="md:text-[16px] text-[14px]">
              <span className="text-[red]">{endTime?.minutes }</span> deqiqe
              </span>
              }
              {!endTime?.seconds == 0 &&
              
              <span className="md:text-[16px] text-[14px]">
              <span className="text-[red]">{endTime?.seconds }</span> saniye
              </span>
              }
              
            </div>
}
          </div>
          <div className="flex md:flex-row flex-col items-center gap-x-[10px] gap-y-[20px]">
            
            {data?data?.result?.status!=='completed' && data?.result?.winnerBidIdn==null &&(<><div className="md:w-1/3 w-full flex items-center  gap-[2px] px-[10px]  border-[1px] border-[#D9D9DE] rounded-[8px] h-[65px]">
              Cari teklif : <span className="text-xl text-[green] font-semibold">{lastBid?.bidAmount || data?.result.startPrice}</span>
            </div>
            <div className="md:w-2/3 w-full flex gap-[10px] items-center">
            {
              data?.result?.bidders?.includes(userReducer?.user?.id) && data?.result?.ownerId !== userReducer?.user?.id && data?.result?.status==='active' &&
              <button onClick={addBid} className="w-1/2 md:py-[16px] py-[16px] px-[40px] md:px-[32px] bg-[#00CD52] rounded-[8px] text-[24px] text-[#fff] font-semibold ">
                Təklif al
              </button>
            }
              {
              !data?.result?.bidders?.includes(userReducer?.user?.id) && data?.result?.ownerId !== userReducer?.user?.id && 
              <>
              <button onClick={handleButtonClick} className="w-1/2 md:py-[16px] py-[16px] px-[40px] md:px-[32px] bg-[#00CD52] rounded-[8px] text-[24px] text-[#fff] font-semibold ">
              Qosul
            </button>
            <Popup show={showPopup} onClose={handleClosePopup} />
      <style jsx>{`
        div {
          display: flex;
          justify-content: center;
          align-items: center;
          height: 100vh;
        }
        button {
          padding: 10px 20px;
          font-size: 16px;
        }
      `}</style>
            </>
            }
            {
              data?.result?.ownerId == userReducer?.user?.id && <p>{data.result?.bidCounts} teklif verilmisdir</p>
            }
              
              <div className="w-1/2 grid grid-cols-2">
                <button className="flex items-center justify-center">
                  <Image src={heartIcon} alt="icon"/>
                </button>
                <button className="flex items-center justify-center">
                  <Image src={shareIcon} alt="icon"/>
                </button>
              </div>
            </div>
            </>):''
}
{
  data?data?.result?.status=='completed' && data?.result?.winnerBidIdn!==null && <p>Lot satilmisdir</p>:""
}
            
          </div>
          <div className=" flex items-center  gap-[50px]">
            
            <div className="flex items-center gap-[5px]">
              <span className="text-[16px] text-[#44415a]">Hər təklif:</span>
              <span className="text-[16px] font-bold text-[#00cd52]">{data?.result?.interval} ₼</span>
            </div>
          </div>
          <div className="w-full flex md:flex-row flex-col items-start gap-[50px]">
            <div className="md:w-3/4 w-full flex md:flex-row flex-col bg-[#04011B] rounded-lg">
              <div className="md:w-3/4  h-[200px] overflow-y-scroll w-full px-[15px] py-[10px] flex flex-col gap-[5px] bg-[#fff] border-[1px] border-[#CDCCD3] rounded-lg  ">
              {
                data?.result && data?.result?.LotBids?.map((item)=>{
                  // console.log(item);
                  return ( 
                    <OfferCard fullname={item.BidUser.first_name} date={new Date(item.createdAt).getDate()} hours={new Date(item.createdAt).getHours()+':'+new Date(item.createdAt).getMinutes()+":"+new Date(item.createdAt).getSeconds()} price={item.bidAmount} key={item.id} />

                  )})
              }
              </div>
              <div className="md:w-1/4 w-full p-[12px] flex md:flex-col flex-row justify-between">
                <div className="flex md:flex-col flex-row md:gap-0 gap-[5px] justify-center items-center text-[#fff]">
                  <span className="text-[16px] md:mb-[-6px]">Təklif</span>
                  <span className="text-[16px]">tarixçəsi</span>
                </div>
                <button className="flex items-center md:w-full md:px-0 px-[15px] text-[#fff] justify-center gap-[4px] bg-[#fff] bg-opacity-10 py-[6px] rounded-[50px]">
                  <span>Siyahı</span>
                  <svg xmlns="http://www.w3.org/2000/svg" width="9" height="8" viewBox="0 0 9 8" fill="none">
                    <path d="M5.08333 1L8 4M8 4L5.08333 7M8 4L1 4" stroke="white" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                </button>
              </div>
            </div>
            <div className="flex justify-center md:w-1/4 w-full">
              {
                data?.result?.status == 'completed' && data?.result?.LotBids.length > 0 &&
                <div className=" w-[150px] text-center h-[150px] bg-[#43d37d] text-[#fff] flex flex-col items-center justify-center gap-[10px] rounded-[140px] border-yellow-400 border-[8px]">
                <span className="text-[14px] ">Satildi!</span>
                <span className="text-[16px] font-bold">{data.result && lastBid?.bidAmount} ₼</span>
              </div>  

              }
              {
                 data?.result?.status == 'active' && 
                 <div className=" w-[150px] text-center h-[150px] bg-[#04011b] text-[#fff] flex flex-col items-center justify-center gap-[10px] rounded-[140px] border-yellow-400 border-[8px]">
                 <span className="text-[14px] ">Yerləşdirildi!</span>
                 <span className="text-[16px] font-bold">{data.result && data?.result?.startPrice} ₼</span>
               </div>
              }
             
            </div>
          </div>

        </div>
      </div>
      <div className="px-[20px] xl:px-[80px] lg:px-[50px]">
        <span className="text-[24px] font-semibold text-[#04011b]">Avtomobil məlumatı</span>
        <div className="mt-[16px] overflow-x-auto">
          {data?.result?.LotDetail && 
          <div className="min-w-[1200px]">
            <CarsCard
              title1="İstehsalçı:" text1={data?.result &&  data?.result?.LotDetail?.manufacturer}
              title2="Model:" text2={data?.result &&  data?.result?.LotDetail?.model}
              title3="Əyləc sistemi:" text3={data?.result &&  data?.result?.LotDetail?.brakeSystem}
              bg={true}
            />
            <CarsCard
              title1="Mühəin Həcmi:" text1={data.result &&  data.result.LotDetail.engineCapacity}
              title2="Marka:" text2={data.result &&  data.result.LotDetail.brand}
              title3="At gücü:" text3={data.result &&  data.result.LotDetail.engine}
              bg={false}
            />
            <CarsCard
              title1="Kategorya:" text1={data.result &&  data.result.LotDetail.vehicleType}
              title2="Rəng:" text2={data.result &&  data.result.LotDetail.color}
              title3="İl:" text3={data.result &&  data.result.LotDetail.year}
              bg={true}
            />
            <CarsCard
              title1="Yanacaq növü:" text1={data.result &&  data.result.LotDetail.fuelType}
              title2="İlk qeydiyyat tarixi:" text2={data.result &&  data.result.LotDetail.year}
              title3="Çəkiş:" text3={data.result &&  data.result.LotDetail.driveType}
              bg={false}
            />
            <CarsCard
              title1="Avtomobil seqmenti:" text1={data.result &&  data.result.LotDetail.carSegments}
              title2="Kilometr:" text2={data.result &&  data.result.LotDetail.mileage}
              title3="Ötürücü növü:" text3={data.result &&  data.result.LotDetail.transmission}
              bg={true}
            />
          
         
          </div>
}
        </div>
      </div>
      <div className="px-[24px] md:px-[80px] mt-[50px] flex flex-col gap-[16px]">
        <span className="text-[24px] font-semibold text-[#050123] ">
          Təfərrüatlar
        </span>
        <p className="text-[16px] text-[#44415a] ">{data.result &&  data.result.detailsText}</p>
      </div>
      <div className="mt-[100px] mb-[120px] px-[20px] md:px-[80px] ">
        <div className="flex items-center justify-between ">
          <span className="text-[24px] font-medium text-[#050123] ">
            Tövsiyə olunanlar
          </span>
          <Link href="/" className="text-[18px] font-medium text-[#E70000]">
            Hamısı
          </Link>
        </div>
        <div className="overflow-auto">
          <div className="flex justify-between gap-[20px] md:gap-[32px] mt-[16px] overflow-auto">
            {recommended.map((item) => {
              return <Card key={item} data={item} />;
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
export default DetailPage;



